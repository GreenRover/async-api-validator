### API Description


Provides access to the Station Switch States.


### Purpose

* Grant visibility over the Station Switch States.

### Target customers

Our target customer is the TrainRunControl DailyTrainDataCalculator.

### Non-functionals

We inform customers directly per email.

### Availability

* Service availability: best effort
* Support: office hours 8:00 - 17:00 CET

### Additional information

[RCS-DispoOp SAD](https://confluence.sbb.ch/x/8QIbS)
[API documentation](https://bin.sbb.ch/artifactory/tmslibs-release.mvn/ch/sbb/tms/capaopt/masterdata-introductioncancellationconfig-api/${maven.artifact.version}/masterdata-introductioncancellationconfig-api-${maven.artifact.version}.zip!/api-documentation.pdf)
